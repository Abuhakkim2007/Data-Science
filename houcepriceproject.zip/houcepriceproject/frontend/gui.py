import pickle
import pandas as pd
from flask import Flask, request, jsonify, render_template
from sklearn.pipeline import Pipeline 
import os 

# --- Configuration and Setup ---
# Configure Flask to look for templates in the current directory (frontend/) 
current_dir = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, template_folder=current_dir)

MODEL_PATH = '../backend/house_price_model.pkl'
FEATURES_PATH = '../backend/feature_names.pkl'
model = None
feature_names = []

# Load the model and feature names once when the app starts
def load_model_artifacts():
    global model, feature_names
    try:
        with open(MODEL_PATH, 'rb') as model_file:
            model = pickle.load(model_file)
        print("✅ Model loaded successfully.")
    except FileNotFoundError:
        print(f"❌ Error: Model file not found at {MODEL_PATH}. Run trainmodel.py first.")
        
    try:
        with open(FEATURES_PATH, 'rb') as features_file:
            feature_names = pickle.load(features_file)
        print("✅ Feature names loaded successfully.")
    except FileNotFoundError:
        print(f"❌ Error: Feature names file not found at {FEATURES_PATH}.")
        print("Prediction API cannot run safely without feature metadata.")


# --- ROUTES ---

@app.route('/', methods=['GET'])
def index():
    """Serves the main house price input form (index.html)."""
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    """
    API endpoint to receive house feature data (JSON) and return a price prediction.
    *** UPDATED: Now uses request.get_json() to match the frontend JS fetch call. ***
    """
    # Check if artifacts were loaded correctly
    if model is None or not feature_names:
        return render_template('error_page.html', 
                               error_message="Service not ready. Model or feature data missing. Please train the model."), 500

    try:
        # 1. GET THE JSON DATA (FIX FOR 400 ERROR)
        # This correctly retrieves the JSON payload sent by the JavaScript fetch function.
        data = request.get_json(force=True)
        
        if not data:
             raise ValueError("No JSON data received.")

        # 2. Extract values in the expected order and validate
        input_data = []
        missing_features = []
        for name in feature_names:
            value = data.get(name)
            if value is None:
                missing_features.append(name)
            input_data.append(value)

        if missing_features:
            # This handles cases where the feature names in the JSON might be missing/incorrect
            raise ValueError(f"Missing required features in JSON payload: {', '.join(missing_features)}")

        # 3. Create a DataFrame for the model
        # Note: We rely on the Frontend JS to ensure the data types are correct (e.g., numbers)
        input_df = pd.DataFrame([input_data], columns=feature_names)

        # 4. Make prediction
        prediction = model.predict(input_df)

        # 5. Format and return the result
        output = {
            'predicted_price': f"${float(prediction[0]):,.2f}"
        }

        return jsonify(output)

    except ValueError as ve:
         # Handles errors related to missing/invalid data fields
         return render_template('error_page.html', 
                               error_message=f"Input/Data Error: {ve}"), 400
    except Exception as e:
        # Catch any general errors during prediction (e.g., model failure)
        return render_template('error_page.html', 
                               error_message=f"An unexpected server error occurred: {str(e)}"), 500


if __name__ == '__main__':
    load_model_artifacts() 
    
    if model:
        print("\nStarting Flask API...")
        app.run(host='0.0.0.0', port=5001, debug=True)
