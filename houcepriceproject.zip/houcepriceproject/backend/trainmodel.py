import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

def train_and_save_model(file_path, model_output_path, features_output_path):
    """
    Loads housing data, trains a Linear Regression model pipeline, and saves it
    along with the feature names.
    """
    print("--- Starting Model Training ---")

    # 1. Load the dataset 
    try:
        df = pd.read_csv(file_path, sep=',')
    except FileNotFoundError:
        print(f"Error: CSV file not found at {file_path}. Ensure 'housing.csv' is in the 'backend' folder.")
        return

    # 2. Data Cleaning and Preparation
    try:
        # Drop the non-numeric 'Address' column and separate target variable 'Price'.
        X = df.drop(['Price', 'Address'], axis=1)
        y = df['Price']
    except KeyError as e:
        print(f"Error: Required column missing - {e}. Check column headers in your CSV.")
        return
        
    # Handle missing values (simple imputation with the mean)
    X = X.fillna(X.mean())

    # 3. Save feature names and order
    feature_names = list(X.columns)
    with open(features_output_path, 'wb') as f:
        pickle.dump(feature_names, f)
    
    # 4. Create a preprocessing and modeling Pipeline
    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('regressor', LinearRegression())
    ])

    # 5. Split data into training and testing sets 
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )

    # 6. Train the model using the pipeline
    pipeline.fit(X_train, y_train)

    # 7. Evaluate and save the trained pipeline
    train_score = pipeline.score(X_train, y_train)
    test_score = pipeline.score(X_test, y_test)
    
    with open(model_output_path, 'wb') as file:
        pickle.dump(pipeline, file)
        
    print(f"Model training complete. Model saved to {model_output_path}")
    print(f"  R-squared (Testing): {test_score:.4f}")

if __name__ == '__main__':
    CSV_FILE = 'housing.csv'
    MODEL_FILE = 'house_price_model.pkl'
    FEATURES_FILE = 'feature_names.pkl'
    
    train_and_save_model(CSV_FILE, MODEL_FILE, FEATURES_FILE)
