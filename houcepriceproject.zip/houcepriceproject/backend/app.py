import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

def train_and_save_model(file_path, model_output_path, features_output_path):
    """
    Loads housing data, trains a Linear Regression model (with scaling), 
    and saves it along with the feature names.
    """
    print("--- Starting Model Training ---")
    
    try:
        df = pd.read_csv(file_path, sep=',')
    except FileNotFoundError:
        print(f"Error: CSV file not found at {file_path}.")
        return

    try:
        # Features X by dropping 'Price' and 'Address'
        X = df.drop(['Price', 'Address'], axis=1)
        y = df['Price']
    except KeyError as e:
        print(f"Error: Required column missing - {e}. Check column headers in your CSV.")
        return
        
    # Handle missing values by filling with the mean
    X = X.fillna(X.mean())

    # Save feature names and order
    feature_names = list(X.columns)
    with open(features_output_path, 'wb') as f:
        pickle.dump(feature_names, f)
    
    # Create the data pipeline (Scaling + Regression)
    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('regressor', LinearRegression())
    ])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )

    # Train the model
    pipeline.fit(X_train, y_train)

    # Save the trained model pipeline
    with open(model_output_path, 'wb') as file:
        pickle.dump(pipeline, file)
        
    print("Model training complete. Model saved to house_price_model.pkl")

if __name__ == '__main__':
    CSV_FILE = 'housing.csv'
    MODEL_FILE = 'house_price_model.pkl'
    FEATURES_FILE = 'feature_names.pkl'
    
    train_and_save_model(CSV_FILE, MODEL_FILE, FEATURES_FILE)
