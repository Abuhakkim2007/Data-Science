import pandas as pd
import pickle
import json
import os
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression

def load_and_predict_locally():
    """
    Loads the trained model and feature data, performs the test prediction,
    and displays the result, bypassing the network API.
    """
    print("--- Starting Local Model Prediction (Bypassing Network) ---")

    # Define paths relative to the script location (backend/)
    MODEL_PATH = 'house_price_model.pkl'
    FEATURES_PATH = 'feature_names.pkl'
    model = None
    feature_names = []

    # 1. Load Model and Features
    try:
        with open(MODEL_PATH, 'rb') as model_file:
            model = pickle.load(model_file)
        with open(FEATURES_PATH, 'rb') as features_file:
            feature_names = pickle.load(features_file)
        print("✅ Model and Feature names loaded successfully.")
    except FileNotFoundError as e:
        print(f"❌ FATAL ERROR: Model artifact file not found: {e}.")
        print("Ensure you ran trainmodel.py successfully to create these files.")
        return

    # 2. Define the Test Data (The same data row we were testing with)
    TEST_HOUSE_DATA = {
        "Avg. Area Income": 79545.46,
        "Avg. Area House Age": 5.68,
        "Avg. Area Number of Rooms": 7.01,
        "Avg. Area Number of Bedrooms": 4.09,
        "Area Population": 23086.8
    }
    
    print("\nTest Data:")
    print(json.dumps(TEST_HOUSE_DATA, indent=4))

    # 3. Prepare the Input for the Model
    try:
        # Extract values in the expected order
        input_data = [TEST_HOUSE_DATA.get(name) for name in feature_names]
        
        # Create a DataFrame. This MUST match the columns/order of the original X_train.
        input_df = pd.DataFrame([input_data], columns=feature_names)

        # 4. Make the Prediction
        prediction = model.predict(input_df)

        # 5. Format and Output the Result
        predicted_price = f"${float(prediction[0]):,.2f}"
        
        print("\n--- ✅ SUCCESSFUL PREDICTION ---")
        print(f"The predicted house price is: **{predicted_price}**")

    except Exception as e:
        print(f"\n❌ Prediction Error: {str(e)}")
        print(f"Check if your test data keys match the expected features: {feature_names}")


if __name__ == '__main__':
    load_and_predict_locally()
